<template>
  <div class="chat-input-container">
    <!-- نمایش پاسخ‌ها در بالای ورودی -->
    <div class="messages-container">
      <div v-for="(item, index) in messages" :key="index" class="message-item" :class="item.type">
        <div class="message-header">
          <div class="avatar" :class="item.type">
            <i :class="item.type === 'user' ? 'fas fa-user' : 'fas fa-robot'"></i>
          </div>
          <div class="sender">{{ item.type === 'user' ? 'شما' : 'دستیار هوشمند' }}</div>
        </div>

        <div class="message-content">
          <!-- پیام کاربر -->
          <div v-if="item.type === 'user'" class="user-message">
            {{ item.text }}
          </div>

          <!-- پاسخ دستیار -->
          <div v-else class="assistant-response">
            <!-- بخش فرمول‌ها -->
            <div v-if="item.formula" class="response-section formula-section">
              <div class="section-header">
                <i class="fas fa-square-root-alt"></i>
                <h4>فرمول:</h4>
              </div>
              <div class="formula-content" ref="mathContent">{{ item.formula }}</div>
            </div>

            <!-- بخش کد -->
            <div v-if="item.code" class="response-section code-section">
              <div class="section-header">
                <i class="fas fa-code"></i>
                <h4>کد:</h4>
              </div>
              <div class="code-block-wrapper">
                <pre class="code-block"><code v-html="highlightCode(item.code)"></code></pre>
                <button class="copy-button" @click="copyToClipboard(item.code)">
                  <i class="fas fa-copy"></i>
                </button>
              </div>
            </div>

            <!-- بخش توضیحات -->
            <div v-if="item.description" class="response-section description-section">
              <div class="section-header">
                <i class="fas fa-info-circle"></i>
                <h4>توضیحات:</h4>
              </div>
              <div class="description-content" v-html="renderMarkdown(item.description)"></div>
            </div>

            <!-- نمایش پاسخ ساده (اگر ساختار خاصی نداشته باشد) -->
            <div v-if="!item.formula && !item.code && !item.description && item.text"
              class="response-section text-section">
              <div class="text-content" v-html="renderMarkdown(item.text)"></div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- ورودی پیام در پایین صفحه (ثابت) -->
    <div class="input-section">
      <div class="input-wrapper">
        <textarea v-model="message" placeholder="پیام خود را بنویسید..." @keydown.enter.prevent="sendMessage"
          :disabled="isDisabled"></textarea>

        <div class="action-buttons">
          <button class="upload-button" @click="triggerFileUpload" :disabled="isDisabled"
            :class="{ 'disabled': isDisabled }">
            <i class="fas fa-file"></i>
          </button>

          <button class="record-button" @click="toggleRecording" :disabled="isDisabled" :class="{
            'recording': isRecording,
            'disabled': isDisabled
          }">
            <i class="fas fa-circle-play"></i>
            <span v-if="isRecording" class="recording-pulse"></span>
          </button>

          <button class="send-button" @click="sendMessage" :disabled="!message.trim() || isDisabled"
            :class="{ 'disabled': !message.trim() || isDisabled }">
            <i class="fas fa-paper-plane"></i>
          </button>
        </div>
      </div>

      <div v-if="isDisabled" class="loading-indicator">
        <div class="loading-spinner"></div>
        <span>در حال پردازش پیام شما...</span>
      </div>

      <input type="file" ref="fileInput" style="display: none" @change="handleFileUpload"
        accept="audio/*,video/*,image/*">
    </div>
  </div>
</template>
<script lang="ts">
import axios from 'axios';
import { marked } from 'marked';
import hljs from 'highlight.js';
import 'highlight.js/styles/atom-one-dark.css';
import katex from 'katex';
import 'katex/dist/katex.min.css';

marked.setOptions({
  highlight: function (code, lang) {
    if (lang && hljs.getLanguage(lang)) {
      return hljs.highlight(code, { language: lang }).value;
    }
    return hljs.highlightAuto(code).value;
  },
  breaks: true,
  gfm: true
});

interface MessageItem {
  type: 'user' | 'assistant';
  text?: string;
  formula?: string;
  code?: string;
  description?: string;
}

export default {
  props: {
    isLoading: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {
      message: '',
      messages: [] as MessageItem[],
      isRecording: false,
      mediaRecorder: null as MediaRecorder | null,
      audioChunks: [] as BlobPart[],
      localLoading: false
    };
  },
  computed: {
    isDisabled() {
      return this.isLoading || this.localLoading;
    }
  },
  watch: {
    messages() {
      this.$nextTick(() => {
        this.scrollToBottom();
      });
    }
  },

  methods: {
    async sendMessage() {
      if (this.message.trim()) {
        try {
          this.messages.push({
            type: 'user',
            text: this.message
          });

          this.localLoading = true;

          const apiResponse = await axios.post('http://127.0.0.1:8000/api/openai/completion/', {
            prompt: this.message
          });

          const formattedResponse = this.processResponse(apiResponse.data);

          this.messages.push({
            type: 'assistant',
            ...formattedResponse
          });

          this.$emit('send', {
            text: this.message,
            response: formattedResponse
          });

          this.message = '';

          this.$nextTick(() => {
            this.renderMathFormulas();
          });
        } catch (error) {
          console.error('Error sending message:', error);
          alert('خطا در دریافت پاسخ از هوش مصنوعی. لطفاً دوباره تلاش کنید.');
        } finally {
          this.localLoading = false;
        }
      }
    },

    processResponse(data: any) {
      if (data.formula || data.code || data.description) {
        return {
          formula: data.formula || null,
          code: data.code || null,
          description: data.description || null
        };
      } else if (data.response || data.answer) {
        const responseText = data.response || data.answer;
        const codeBlocks = this.extractCodeBlocks(responseText);
        const formulaBlocks = this.extractFormulaBlocks(responseText);

        if (codeBlocks.length > 0 || formulaBlocks.length > 0) {
          return {
            code: codeBlocks.length > 0 ? codeBlocks.join('\n\n') : null,
            formula: formulaBlocks.length > 0 ? formulaBlocks.join('\n\n') : null,
            description: this.removeBlocksFromText(responseText, [...codeBlocks, ...formulaBlocks])
          };
        } else {
          return {
            text: responseText
          };
        }
      } else {
        return {
          text: JSON.stringify(data)
        };
      }
    },

    extractCodeBlocks(text: string): string[] {
      const codeBlockRegex = /```(?:(\w+))?\s*([\s\S]*?)```/g;
      const matches = [];
      let match;

      while ((match = codeBlockRegex.exec(text)) !== null) {
        const lang = match[1] || '';
        const code = match[2].trim();
        matches.push(`${lang}\n${code}`);
      }

      return matches;
    },

    extractFormulaBlocks(text: string): string[] {
      const formulaBlockRegex = /\$\$([\s\S]*?)\$\$|\$([\s\S]*?)\$/g;
      const matches = [];
      let match;

      while ((match = formulaBlockRegex.exec(text)) !== null) {
        matches.push(match[1] || match[2]);
      }

      return matches;
    },

    removeBlocksFromText(text: string, blocks: string[]): string {
      let result = text;
      result = result.replace(/```(?:\w+)?\s*[\s\S]*?```/g, '');
      result = result.replace(/\$\$[\s\S]*?\$\$|\$[\s\S]*?\$/g, '');
      result = result.replace(/\n{3,}/g, '\n\n');
      return result.trim();
    },

    renderMarkdown(text: string | null | undefined): string {
      if (!text) return '';

      let processedText = text.replace(/\$([^$]+)\$/g, (match, formula) => {
        try {
          return katex.renderToString(formula, { throwOnError: false });
        } catch (e) {
          console.error('KaTeX error:', e);
          return match;
        }
      });

      const html = marked(processedText);

      this.$nextTick(() => {
        this.enhanceCodeBlocksWithCopy();
      });

      return html;
    },

    enhanceCodeBlocksWithCopy() {
      this.$nextTick(() => {
        const codeBlocks = this.$el.querySelectorAll('.description-content pre code, .text-content pre code');

        codeBlocks.forEach(block => {
          const wrapper = block.parentElement;
          if (!wrapper?.querySelector('.copy-button')) {
            const button = document.createElement('button');
            button.className = 'copy-button';
            button.innerHTML = '<i class="fas fa-copy"></i>';
            button.addEventListener('click', () => {
              navigator.clipboard.writeText(block.textContent || '').then(() => {
                alert('کد در کلیپ‌بورد کپی شد!');
              });
            });
            wrapper.style.position = 'relative';
            wrapper.appendChild(button);
          }
        });
      });
    },

    renderMathFormulas() {
      this.$nextTick(() => {
        const mathElements = this.$el.querySelectorAll('.formula-content');
        mathElements.forEach(element => {
          try {
            const formula = element.textContent || '';
            katex.render(formula, element as HTMLElement, {
              throwOnError: false,
              displayMode: true
            });
          } catch (e) {
            console.error('KaTeX rendering error:', e);
          }
        });
      });
    },

    highlightCode(code: string | null | undefined): string {
      if (!code) return '';

      const lines = code.split('\n');
      let language = lines[0].trim();
      let codeContent = lines.slice(1).join('\n');

      if (!hljs.getLanguage(language)) {
        language = this.detectCodeLanguage(code);
        codeContent = code;
      }

      if (language && hljs.getLanguage(language)) {
        return hljs.highlight(codeContent, { language }).value;
      }

      return hljs.highlightAuto(codeContent).value;
    },

    detectCodeLanguage(code: string): string {
      if (code.includes('import') && code.includes('from') && (code.includes('def ') || code.includes('class '))) {
        return 'python';
      } else if (code.includes('function') && (code.includes('const ') || code.includes('let ') || code.includes('var '))) {
        return 'javascript';
      } else if (code.includes('<template>') && code.includes('<script>') && code.includes('<style>')) {
        return 'vue';
      } else if (code.includes('public class') || code.includes('private class') || code.includes('protected class')) {
        return 'java';
      } else if (code.includes('#include') && (code.includes('int main') || code.includes('void main'))) {
        return 'cpp';
      } else if (code.includes('<?php')) {
        return 'php';
      }

      return '';
    },

    copyToClipboard(text: string | null | undefined) {
      if (!text) return;

      navigator.clipboard.writeText(text)
        .then(() => {
          alert('کد در کلیپ‌بورد کپی شد!');
        })
        .catch(err => {
          console.error('خطا در کپی کردن متن: ', err);
        });
    },

    scrollToBottom() {
      this.$nextTick(() => {
        const container = this.$el.querySelector('.messages-container');
        if (container) {
          container.scrollTop = container.scrollHeight;
        }
      });
    },

    triggerFileUpload() {
      (this.$refs.fileInput as HTMLInputElement).click();
    },

    handleFileUpload(event: Event) {
      const file = (event.target as HTMLInputElement).files?.[0];
      if (file) {
        this.$emit('file-uploaded', file);
      }
    },

    async toggleRecording() {
      if (this.isRecording) {
        this.stopRecording();
      } else {
        await this.startRecording();
      }
    },

    async startRecording() {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        this.mediaRecorder = new MediaRecorder(stream);
        this.audioChunks = [];

        this.mediaRecorder.addEventListener('dataavailable', (event) => {
          this.audioChunks.push(event.data);
        });

        this.mediaRecorder.addEventListener('stop', () => {
          const audioBlob = new Blob(this.audioChunks, { type: 'audio/webm' });
          this.$emit('audio-recorded', audioBlob);
          this.isRecording = false;
          stream.getTracks().forEach(track => track.stop());
        });

        this.mediaRecorder.start();
        this.isRecording = true;
      } catch (error) {
        console.error('Error accessing microphone:', error);
        alert('خطا در دسترسی به میکروفون. لطفاً مجوزهای دسترسی را بررسی کنید.');
      }
    },

    stopRecording() {
      if (this.mediaRecorder && this.mediaRecorder.state !== 'inactive') {
        this.mediaRecorder.stop();
      }
    }
  },
  mounted() {
    if (!document.getElementById('font-awesome-css')) {
      const link = document.createElement('link');
      link.id = 'font-awesome-css';
      link.rel = 'stylesheet';
      link.href = 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css';
      document.head.appendChild(link);
    }

    this.scrollToBottom(); // initial scroll
  }
};
</script>


<style scoped>
.chat-input-container {
  display: flex;
  flex-direction: column;
  height: 100vh;
  background-color: #343541;
  font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
  direction: rtl;
}

/* بخش پیام‌ها */
.messages-container {
  flex: 1;
  overflow-y: auto;
  padding: 30px;
  display: flex;
  flex-direction: column;
  gap: 20px;
  min-height: 0;
  /* اضافه کنید */
}

.message-item {
  display: flex;
  flex-direction: column;
  max-width: 90%;
  border-radius: 12px;
  overflow: visible;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
  margin-bottom: 10px;
  /* فاصله بین پیام‌ها */
}

.message-item.user {
  align-self: flex-end;
  background-color: #10a37f;
}

.message-item.assistant {
  align-self: flex-start;
  background-color: #444654;
  max-width: 90%;
}

.message-header {
  display: flex;
  align-items: center;
  padding: 10px 15px;
  background-color: rgba(0, 0, 0, 0.1);
}

.avatar {
  width: 30px;
  height: 30px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  margin-left: 10px;
  color: white;
}

.avatar.user {
  background-color: #0d8c6d;
}

.avatar.assistant {
  background-color: #565869;
}

.sender {
  font-weight: 600;
  color: white;
}

.message-content {
  padding: 15px;
  color: white;
}

.user-message {
  white-space: pre-wrap;
  word-break: break-word;
}

/* بخش ورودی */
.input-section {
  padding: 20px;
  border-top: 1px solid #565869;
  background-color: #343541;
}

.input-wrapper {
  position: relative;
  display: flex;
  gap: 10px;
  align-items: flex-end;
  background-color: #40414f;
  border-radius: 12px;
  padding: 8px;
  max-width: 800px;
  margin: 0 auto;
  width: 100%;
}

textarea {
  flex: 1;
  min-height: 40px;
  max-height: 120px;
  padding: 10px;
  padding-right: 90px;
  border-radius: 8px;
  border: 1px solid #565869;
  background-color: #40414f;
  color: #fff;
  resize: none;
  font-size: 14px;
  line-height: 1.4;
  direction: rtl;
}

textarea:disabled {
  opacity: 0.7;
  cursor: not-allowed;
}

.action-buttons {
  display: flex;
  gap: 12px;
  position: absolute;
  left: 10px;
  bottom: 25px;
}

button {
  background: none;
  border: none;
  color: #fff;
  cursor: pointer;
  padding: 8px 12px;
  border-radius: 4px;
  transition: all 0.2s;
  display: flex;
  align-items: center;
  justify-content: center;
  min-width: 36px;
  min-height: 36px;
}

button i {
  font-size: 18px;
}

button:hover:not(.disabled) {
  background-color: #565869;
}

.disabled {
  opacity: 0.5;
  cursor: not-allowed !important;
}

.loading-indicator {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 10px;
  padding: 8px;
  background-color: rgba(52, 53, 65, 0.9);
  border-radius: 8px;
  margin-top: 8px;
  color: #fff;
}

.loading-spinner {
  width: 20px;
  height: 20px;
  border: 2px solid #ffffff;
  border-radius: 50%;
  border-top-color: transparent;
  animation: spin 1s linear infinite;
}

@keyframes spin {
  to {
    transform: rotate(360deg);
  }
}

.recording-pulse {
  position: absolute;
  width: 12px;
  height: 12px;
  background-color: #ff4444;
  border-radius: 50%;
  right: 0;
  top: 0;
  animation: pulse 1.5s ease infinite;
}

@keyframes pulse {
  0% {
    transform: scale(1);
    opacity: 1;
  }

  50% {
    transform: scale(1.5);
    opacity: 0.5;
  }

  100% {
    transform: scale(1);
    opacity: 1;
  }
}

.record-button.recording {
  color: #ff4444;
  position: relative;
}

/* استایل‌های بخش پاسخ */
.assistant-response {
  display: flex;
  flex-direction: column;
  gap: 15px;
}

.response-section {
  background-color: #40414f;
  border-radius: 8px;
  padding: 12px;
  box-shadow: 0 1px 4px rgba(0, 0, 0, 0.1);
  margin-bottom: 10px;
}

.section-header {
  display: flex;
  align-items: center;
  margin-bottom: 8px;
  color: #fff;
}

.section-header i {
  margin-left: 8px;
  color: #10a37f;
}

.section-header h4 {
  margin: 0;
  font-size: 16px;
  font-weight: 600;
}

.formula-section {
  border-right: 3px solid #ff9800;
}

.code-section {
  border-right: 3px solid #2196f3;
}

.description-section {
  border-right: 3px solid #4caf50;
}

.text-section {
  border-right: 3px solid #9c27b0;
}

.code-block-wrapper {
  position: relative;
}

.code-block {
  background-color: #2d2d2d;
  border-radius: 6px;
  padding: 12px;
  margin: 0;
  overflow-x: auto;
  font-family: 'Fira Code', 'Courier New', monospace;
  font-size: 14px;
  line-height: 1.5;
  direction: ltr;
  text-align: left;
}

.copy-button {
  position: absolute;
  top: 8px;
  right: 8px;
  background-color: rgba(255, 255, 255, 0.1);
  border-radius: 4px;
  padding: 4px 8px;
  color: #fff;
  font-size: 12px;
  opacity: 0.7;
  transition: opacity 0.2s;
}

.copy-button:hover {
  opacity: 1;
  background-color: rgba(255, 255, 255, 0.2);
}

.formula-content,
.description-content,
.text-content {
  color: #fff;
  line-height: 1.6;
}

.formula-content {
  background-color: #2d2d2d;
  padding: 10px;
  border-radius: 6px;
  overflow-x: auto;
  text-align: center;
  direction: ltr;
}

/* استایل‌های مارک‌داون */
:deep(h1),
:deep(h2),
:deep(h3),
:deep(h4),
:deep(h5),
:deep(h6) {
  color: #fff;
  margin-top: 16px;
  margin-bottom: 8px;
}

:deep(p) {
  margin-bottom: 12px;
}

:deep(a) {
  color: #10a37f;
  text-decoration: none;
}

:deep(a:hover) {
  text-decoration: underline;
}

:deep(ul),
:deep(ol) {
  padding-right: 20px;
  margin-bottom: 12px;
}

:deep(li) {
  margin-bottom: 4px;
}

:deep(blockquote) {
  border-right: 3px solid #10a37f;
  margin: 0;
  padding: 0 12px;
  color: #ccc;
}

:deep(code:not(pre code)) {
  background-color: rgba(0, 0, 0, 0.2);
  padding: 2px 4px;
  border-radius: 3px;
  font-family: 'Fira Code', 'Courier New', monospace;
  font-size: 0.9em;
}

:deep(table) {
  border-collapse: collapse;
  width: 100%;
  margin-bottom: 16px;
}

:deep(th),
:deep(td) {
  border: 1px solid #565869;
  padding: 8px;
  text-align: right;
}

:deep(th) {
  background-color: #40414f;
}

:deep(img) {
  max-width: 100%;
  border-radius: 4px;
}

/* استایل‌های KaTeX */
:deep(.katex-display) {
  margin: 0.5em 0;
  overflow-x: auto;
  overflow-y: hidden;
  padding: 8px 0;
}

:deep(.katex) {
  font-size: 1.1em;
}
</style>